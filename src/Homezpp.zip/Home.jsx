import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import io from 'socket.io-client';
import 'F:/project/MERNTASK/livechat/src/CSS/home.css'; // Update the path based on your folder structure
import mchatLogo from 'F:/project/MERNTASK/livechat/public/images/mchatlogo.png'; // Make sure the image is in src/assets

const socket = io("http://localhost:3000");

export const Home = () => {
  const [users, setUsers] = useState([]);
  const [activeUser, setActiveUser] = useState(null);
  const [messages, setMessages] = useState({});
  const [newMessage, setNewMessage] = useState('');
  const bottomRef = useRef(null);

  // Load users from localStorage or fetch
  useEffect(() => {
    const storedUsers = localStorage.getItem('users');
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers));
    } else {
      axios.get('http://localhost:3000/getuser')
        .then(res => {
          setUsers(res.data);
          localStorage.setItem('users', JSON.stringify(res.data));
        })
        .catch(err => console.error("Error fetching users", err));
    }
  }, []);

  // Load messages from localStorage
  useEffect(() => {
    const storedMessages = localStorage.getItem('messages');
    if (storedMessages) {
      setMessages(JSON.parse(storedMessages));
    }
  }, []);

  // Handle socket connect/disconnect
  useEffect(() => {
    const onConnect = () => console.log("Connected to socket server");
    const onDisconnect = () => console.log("Disconnected from socket server");

    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);

    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
    };
  }, []);

  // Receive messages
  useEffect(() => {
    const handleReceive = ({ senderId, message }) => {
      setMessages(prev => {
        const updated = {
          ...prev,
          [senderId]: [...(prev[senderId] || []), { from: senderId, text: message }]
        };
        localStorage.setItem('messages', JSON.stringify(updated));
        return updated;
      });
    };

    socket.on("receive_message", handleReceive);
    return () => socket.off("receive_message", handleReceive);
  }, []);

  // Auto-scroll to latest message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeUser]);

  const handleUserClick = (user) => {
    setActiveUser(user);
  };

  const handleSend = () => {
    if (newMessage.trim() && activeUser) {
      const payload = {
        senderId: "me",
        receiverId: activeUser._id,
        message: newMessage,
      };

      socket.emit("send_message", payload);

      setMessages(prev => {
        const updated = {
          ...prev,
          [activeUser._id]: [...(prev[activeUser._id] || []), { from: 'me', text: newMessage }]
        };
        localStorage.setItem('messages', JSON.stringify(updated));
        return updated;
      });

      setNewMessage('');
    }
  };

  return (
    <div className="app-container">
      <div className="sidebar">
        <input type="text" placeholder="Search or start a new chat" />
        <div className="chat-list">
          {users.map((user, index) => (
            <div
              className={`chat-item ${activeUser?._id === user._id ? 'active' : ''}`}
              key={index}
              onClick={() => handleUserClick(user)}
            >
              <div className="chat-name">{user.name}</div>
              <div className="chat-info">
                <span className="chat-time">{user.email}</span>
                <span className="chat-message">{user.phone}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="main-chat-area">
        {activeUser ? (
          <div className="chat-window">
            <h2>Chat with {activeUser.name}</h2>
            <div className="messages">
              {(messages[activeUser._id] || []).map((msg, i) => (
                <div key={i} className={`message ${msg.from === 'me' ? 'sent' : 'received'}`}>
                  {msg.text}
                </div>
              ))}
              <div ref={bottomRef} />
            </div>
            <div className="input-area">
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type a message"
              />
              <button onClick={handleSend}>Send</button>
            </div>
          </div>
        ) : (
          <div className="empty-chat">
            <img src={mchatLogo} alt="Chat Logo" style={{ height: "120px" }} />
            <p>WhatsApp for Windows</p>
            <p>Send and receive messages without keeping your phone online.</p>
            <p>Use WhatsApp on up to 4 linked devices and 1 phone at the same time.</p>
            <p><strong>End-to-end encrypted</strong></p>
          </div>
        )}
      </div>
    </div>
  );
};
